import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  items: [
    {
      bookId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Book"
      },
      title: String,
      price: Number,
      qty: Number,
       image: String
    }
  ],
  totalAmount: Number,
  paymentMethod: String,
  paymentStatus: String,
  status: {
  type: String,
  enum: ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"],
  default: "Pending"
},
  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model("Order", orderSchema);
