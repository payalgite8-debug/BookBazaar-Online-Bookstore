// admin/app.mjs
import path from "path";
import { fileURLToPath } from "url";
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import multer from "multer";
import bcrypt from "bcryptjs";
import session from "express-session";

// MODELS
import Admin from "./models/Admin.js";
import Book from "./models/Book.js"; // ✅ Ensure filename matches exactly
import Order from "./models/Order.js";
import User from "./models/User.js";
import Wishlist from "./models/Wishlist.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use(session({
  secret: "bookbazaar-admin-secret",
  resave: false,
  saveUninitialized: false
}));

// 🔐 ADMIN AUTH MIDDLEWARE
function adminAuth(req, res, next) {
  if (req.session.admin) {
    next();
  } else {
    res.redirect("/admin-login");
  }
}


app.set("views", path.join(process.cwd(),"admin", "views"));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use("/admin", express.static(path.join(__dirname, "public")));

// 🔌 MONGODB CONNECTION
mongoose
  .connect("mongodb://localhost:27017/BookBazaar")
  .then(() => console.log("📌 MongoDB Connected"))
  .catch((err) => console.log("❌ DB Connection Error:", err));


app.get("/admin/dashboard-stats", async (req, res) => {
  try {
    const totalBooks = await Book.countDocuments();
    const totalUsers = await User.countDocuments();
    const totalOrders = await Order.countDocuments();

    const pendingOrders = await Order.countDocuments({
      status: "Order Placed" // 🔥 FIX HERE
    });

    res.json({
      totalBooks,
      totalUsers,
      totalOrders,
      pendingOrders
    });
  } catch (err) {
    console.error("Dashboard Stats Error:", err);
    res.status(500).json({ message: "Dashboard stats error" });
  }
});

// Serve login page
app.get("/", (req, res) => {
  res.sendFile("login.html", { root: "public" });
});

// 🔐 ADMIN LOGIN PAGE
app.get("/admin-login", (req, res) => {
  res.render("login", { message: null }); 
});

app.post("/admin/login", async (req, res) => {
  const { email, password } = req.body;

  const admin = await Admin.findOne({ email });
  if (!admin) {
    return res.json({ success: false, message: "Admin not found" });
  }

  const isMatch = await bcrypt.compare(password, admin.password);
  if (!isMatch) {
    return res.json({ success: false, message: "Wrong password" });
  }

  req.session.admin = true;
  res.json({ success: true, message: "Login successful" });
});
// 🚪 ADMIN LOGOUT
app.get("/admin-logout", (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.log("Logout error:", err);
      return res.redirect("/admin/dashboard");
    }
    res.redirect("/");
  });
});

app.get("/dashboard", async (req, res) => {
  const totalBooks = await Book.countDocuments();
  const totalOrders = await Order.countDocuments();
  const totalUsers = await User.countDocuments();
const pendingOrders = await Order.countDocuments({
  status: "Order Placed"
});

  res.render("dashboard", {
    totalBooks,
    totalOrders,
    totalUsers,
    pendingOrders
  });
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "public/uploads"),
  filename: (req, file, cb) =>
    cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage });

// Serve books list page
app.get("/admin/books", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "books.html"));
});

// Serve add book page
app.get("/admin/addBook", (req, res) => {
  res.sendFile("addBook.html", { root: "public" });
});

// POST add new book with image
app.post("/admin/addBook", upload.single("image"), async (req, res) => {
  try {
    const { title, author, price, description, stock } = req.body;
    const image = req.file ? req.file.filename : null;

    const newBook = new Book({ title, author, price, description, stock, image });
    await newBook.save();

    res.json({ success: true, message: "Book added successfully!" });
  } catch (err) {
    console.log("Add Book Error:", err);
    res.json({ success: false, message: "Error adding book" });
  }
});

// Get all books as JSON
app.get("/admin/get-books", async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    console.log(err);
    res.json([]);
  }
});

// Delete book
app.delete("/admin/delete-book/:id", async (req, res) => {
  try {
    await Book.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    console.log(err);
    res.json({ success: false });
  }
});

app.get("/admin/editBook", (req, res) => {
  // editBook.html should be in admin/public
  res.sendFile("editBook.html", { root: path.join(__dirname, "public") });
});

app.get("/admin/editBook/:id", (req, res) => {
  res.sendFile("editBook.html", { root: path.join(__dirname, "public") });
});

app.put("/admin/update-book/:id", upload.single("image"), async (req, res) => {
  try {
    const { title, author, price, stock, description } = req.body;
    const updateData = { title, author, price, stock, description };

    if (req.file) updateData.image = req.file.filename;

    await Book.findByIdAndUpdate(req.params.id, updateData);
    res.json({ success: true, message: "Book updated successfully!" });
  } catch (error) {
    res.json({ success: false, message: "Failed to update book" });
  }
});

app.get("/admin/book/:id", async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    res.json(book);
  } catch (err) {
    res.status(500).json({ error: "Book not found" });
  }
});

app.get("/admin/orders", async (req, res) => {
  try {
    const orders = await Order.find().populate("userId");
    res.render("orders", { orders });
  } catch (err) {
    console.log(err);
    res.send("Error loading orders");
  }
});

app.post("/admin/order-status/:id", async (req, res) => {
  await Order.findByIdAndUpdate(req.params.id, {
    status: req.body.status
  });

  res.redirect("/admin/orders");
});

// ADMIN - USERS LIST PAGE
app.get("/admin/users", async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });

    const usersWithOrders = await Promise.all(
      users.map(async (user) => {
        const orderCount = await Order.countDocuments({
          userId: user._id,
        });

        return {
          ...user.toObject(),
          orderCount,
        };
      })
    );

    res.render("users", {
      users: usersWithOrders,
    });
  } catch (err) {
    console.error("Admin Users Error:", err);
    res.status(500).send("Error loading users");
  }
});

// 🧾 GET SINGLE USER DETAILS (FOR MODAL)
app.get("/admin/users/:id/details", async (req, res) => {
  try {
    const user = await User.findById(req.params.id).lean();
    if (!user) return res.status(404).json({ error: "User not found" });

    const orderCount = await Order.countDocuments({ userId: user._id });

    res.json({
      name: user.name,
      email: user.email,
      isBlocked: user.isBlocked,
      createdAt: user.createdAt,
      orderCount
    });
  } catch (err) {
    console.error("User Details Error:", err);
    res.status(500).json({ error: "Server error" });
  }
});


// 🔥 SERVER START
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`⚡ Admin server running on http://localhost:${PORT}`);
});
