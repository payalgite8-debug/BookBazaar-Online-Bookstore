import mongoose from "mongoose";

const BookSchema = new mongoose.Schema({
  title: String,
  author: String,
  price: Number,
  description: String,
  stock: Number,
  image: String
});

export default mongoose.model("Book", BookSchema);
