import mongoose from "mongoose";

const addressSchema = new mongoose.Schema({
  fullName: String,
  phone: String,
  address: String,
  city: String,
  state: String,
  pincode: String
});

const userSchema = new mongoose.Schema({
  name: String,
  mobile: String,
  email: String,
  password: String,

  profileImage: {
    type: String,
    default: "/images/default-user.png"
  },

  // ✅ Saved addresses
  addresses: [addressSchema],

  // ✅ OTP fields (LOGIN + FORGOT PASSWORD ke liye)
  otp: String,
  otpExpire: Date
});

export default mongoose.model("User", userSchema);
