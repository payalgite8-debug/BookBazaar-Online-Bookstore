import crypto from "crypto";
import path from "path";
import Order from "./models/Order.js";
import express from "express";
import multer from "multer";
import dotenv from "dotenv";
import mongoose from "mongoose";
import bodyParser from "body-parser";
import session from "express-session";
import bcrypt from "bcrypt";
import Razorpay from "razorpay";
import User from "./models/User.js";
import Book from "./models/Book.js";
import Wishlist from "./models/Wishlist.js";
import otpGenerator from "otp-generator";
import { sendOtpEmail } from "./utils/sendOtp.js";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.urlencoded({ extended: true }));



app.use(express.static("public"));
app.use("..../uploads", express.static("uploads"));
app.use(express.static(path.join(process.cwd(), "public")));
app.set("view engine", "ejs");

// Session
app.use(session({
  secret: "bookbazaar-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));

// 🔐 LOGIN GUARD MIDDLEWARE
function loginGuard(req, res, next) {
  if (!req.session.user) {
    return res.redirect("/login");
  }
  next();
}

app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// MongoDB connect
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.log("MongoDB Connection Error:", err));

  const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Home
app.get("/", (req, res) => {
  res.render("index", { user: req.session.user });
});

// Register GET
app.get("/register", (req, res) => {
  res.render("register", { message: "" });
});

// Register POST
app.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.render("register", { message: "Email already exists!" });

    const hashedPass = await bcrypt.hash(password, 10);
    await User.create({ name, email, password: hashedPass });

    res.render("register", { message: "Registration Successful!" });
  } catch {
    res.render("register", { message: "Something went wrong!" });
  }
});

// Login GET
app.get("/login", (req, res) => {
  res.render("login", { message: "" });
});

// Login POST
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });
  if (!user) return res.render("login", { message: "User not found" });

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.render("login", { message: "Wrong password" });

  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  user.otp = otp;
  user.otpExpire = Date.now() + 1 * 60 * 1000; // 2 min
  await user.save();

  await sendOtpEmail(user.email, otp);

  req.session.tempUserId = user._id;
  res.redirect("/verify-otp");
});

app.get("/verify-otp", (req, res) => {
  res.render("verify-otp");
});

app.post("/verify-otp", async (req, res) => {
  const { otp } = req.body;

  const user = await User.findById(req.session.tempUserId);

  if (!user || user.otp !== otp || user.otpExpire < Date.now()) {
    return res.render("verify-otp", { error: "Invalid or expired OTP" });
  }

  user.otp = null;
  user.otpExpire = null;
  await user.save();

  req.session.user = {
    id: user._id,
    name: user.name,
    email: user.email
  };

  res.redirect("/dashboard");
});

app.post("/resend-otp", async (req, res) => {
  if (!req.session.tempUserId) {
    return res.redirect("/login");
  }

  const user = await User.findById(req.session.tempUserId);
  if (!user) return res.redirect("/login");

  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  user.otp = otp;
  user.otpExpire = Date.now() + 1 * 60 * 1000; // 2 min
  await user.save();

  // email bhejne ka function
  await sendOtpEmail(user.email, otp);

  res.redirect("/verify-otp");
});

app.get("/forgot-password", (req, res) => {
  res.render("forgot-password", {
    error: null
  });
});

app.post("/forgot-password", async (req, res) => {
  const { email } = req.body;

  const user = await User.findOne({ email });
  if (!user) {
    return res.render("forgot-password", {
      error: "Email not registered"
    });
  }

  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  user.otp = otp;
  user.otpExpire = Date.now() + 1 * 60 * 1000;
  await user.save();

  // email function
  await sendOtpEmail(user.email, otp);

  req.session.tempUserId = user._id;
  req.session.resetPassword = true;

  res.redirect("/verify-otp");
});

app.post("/reset-password", async (req, res) => {
  const { otp, password } = req.body;

  const user = await User.findById(req.session.resetUserId);

  if (!user || user.otp !== otp || user.otpExpire < Date.now()) {
    return res.render("reset-password", { error: "Invalid OTP" });
  }

  user.password = await bcrypt.hash(password, 10);
  user.otp = null;
  user.otpExpire = null;

  await user.save();
  res.redirect("/login");
});

// Dashboard
app.get("/dashboard", loginGuard, (req, res) => {
  if (!req.session.user) return res.redirect("/login");
  res.render("dashboard", { user: req.session.user });
});

// 🛒 ADD TO CART
app.post("/add-to-cart/:id", async (req, res) => {
  if (!req.session.cart) {
    req.session.cart = [];
  }

  const bookId = req.params.id;
  const book = await Book.findById(bookId);

  if (!book) return res.redirect("/browseBooks");

  const existingItem = req.session.cart.find(
    item => item.book._id.toString() === bookId
  );

  if (existingItem) {
    existingItem.qty += 1;
  } else {
    req.session.cart.push({
      book,
      qty: 1
    });
  }

  res.redirect("/cart");
});

// ➕ INCREASE QTY
app.post("/cart/increase/:id", (req, res) => {
  const cart = req.session.cart || [];

  const item = cart.find(
    i => i.book._id.toString() === req.params.id
  );

  if (item) item.qty += 1;

  res.redirect("/cart");
});

// ➖ DECREASE QTY
app.post("/cart/decrease/:id", (req, res) => {
  const cart = req.session.cart || [];

  const item = cart.find(
    i => i.book._id.toString() === req.params.id
  );

  if (item && item.qty > 1) {
    item.qty -= 1;
  }

  res.redirect("/cart");
});

// 🗑 REMOVE ITEM FROM CART
app.post("/cart/remove/:id", (req, res) => {
  let cart = req.session.cart || [];

  cart = cart.filter(
    item => item.book._id.toString() !== req.params.id
  );

  req.session.cart = cart;
  res.redirect("/cart");
});

// All Books Page (User View)
app.get("/books", async (req, res) => {
  const books = await Book.find({});
  res.render("books", { books, user: req.session.user });
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

// Browse Books (User Side)
app.get("/browseBooks", async (req, res) => {
  let { search = "", sort = "" } = req.query;

  let query = {};

  if (search) {
    query.$or = [
      { title: { $regex: search, $options: "i" } },
      { author: { $regex: search, $options: "i" } }
    ];
  }

  let sortOption = {};
  if (sort === "low") sortOption.price = 1;
  if (sort === "high") sortOption.price = -1;

  const books = await Book.find(query).sort(sortOption);

  res.render("browseBooks", {
    books,
    search,   // ✅ ALWAYS defined
    sort      // ✅ ALWAYS defined
  });
});

// 🔍 LIVE SEARCH API
app.get("/api/books/search", async (req, res) => {
  const query = req.query.q || "";

  const books = await Book.find({
    $or: [
      { title: { $regex: query, $options: "i" } },
      { author: { $regex: query, $options: "i" } }
    ]
  });

  res.json(books);
});

// Single book details
app.get("/book/:id", async (req, res) => {
  const book = await Book.findById(req.params.id);

  let isWishlisted = false;

  if (req.session.user) {
    const wish = await Wishlist.findOne({
      userId: req.session.user.id,
      bookId: book._id
    });
    isWishlisted = !!wish;
  }

  res.render("bookDetails", {
    book,
    isWishlisted,
    user: req.session.user
  });
});

// 🛒 CART PAGE
app.get("/cart", (req, res) => {
  const cart = req.session.cart || [];
  res.render("cart", { cart });
});

// Add to Cart (item add)
app.post("/add-to-cart/:id", async (req, res) => {
  if (!req.session.cart) {
    req.session.cart = [];
  }

  const bookId = req.params.id;

  // duplicate prevent
  const alreadyInCart = req.session.cart.find(
    item => item.book && item.book._id.toString() === bookId
  );

  if (!alreadyInCart) {
    const book = await Book.findById(bookId);
    req.session.cart.push({
      book: book,
      qty: 1
    });
  }

  res.redirect("/cart"); // ✅ sirf cart page
});

app.post("/buy-now/:id", loginGuard, async (req, res) => {
  const book = await Book.findById(req.params.id);

  req.session.buyNow = [{
    book,
    qty: 1
  }];

  res.redirect("/checkout");
});

// ✅ CHECKOUT PAGE
app.get("/checkout", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const user = await User.findById(req.session.user.id);

  res.render("checkout", {
    cart: req.session.cart || [],
    addresses: user.addresses
  });
});

// 📦 SAVE ADDRESS & MOVE TO PAYMENT (DUPLICATE CHECK FIX)
app.post("/checkout", async (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }

  const user = await User.findById(req.session.user.id);

  const exists = user.addresses.find(addr =>
    addr.fullName === req.body.fullName &&
    addr.phone === req.body.phone &&
    addr.address === req.body.address &&
    addr.city === req.body.city &&
    addr.state === req.body.state &&
    addr.pincode === req.body.pincode
  );

  // ✅ Agar address pehle se nahi hai tabhi save karo
  if (!exists) {
    user.addresses.push({
      fullName: req.body.fullName,
      phone: req.body.phone,
      address: req.body.address,
      city: req.body.city,
      state: req.body.state,
      pincode: req.body.pincode
    });

    await user.save();
  }

  res.redirect("/payment");
});

app.post("/checkout/address/delete/:id", async (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }

  const userId = req.session.user.id;   // ✅ FIXED
  const addressId = req.params.id;

  await User.findByIdAndUpdate(userId, {
    $pull: { addresses: { _id: addressId } }
  });

  res.redirect("/checkout");
});

app.get("/payment", (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const items = req.session.buyNow || req.session.cart;

  if (!items || items.length === 0) return res.redirect("/cart");

  res.render("payment", {
    cart: items,
    razorpayKey: process.env.RAZORPAY_KEY_ID
  });
});

app.post("/order/cod", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const cart = req.session.buyNow || req.session.cart; // ✅ FIX
  const user = req.session.user;

  let totalAmount = 0;
  const items = cart.map(item => {
    totalAmount += item.book.price * item.qty;
    return {
      bookId: item.book._id,
      title: item.book.title,
      price: item.book.price,
      qty: item.qty,
      image: item.book.image
    };
  });

  const order = await Order.create({
    userId: user.id,
    items,
    totalAmount,
    paymentMethod: "COD",
    paymentStatus: "PENDING",
    status: "Order Placed"
  });

  req.session.cart = [];
  req.session.buyNow = null; // ✅ VERY IMPORTANT

  res.redirect(`/order-success/${order._id}`);
});

app.post("/create-order", async (req, res) => {
  try {
    const cart = req.session.buyNow || req.session.cart;
    const user = req.session.user;

    if (!cart || cart.length === 0) {
      return res.status(400).json({ error: "Cart empty" });
    }

    let totalAmount = 0;

    const items = cart.map(item => {
      totalAmount += item.book.price * item.qty;
      return {
        bookId: item.book._id,
        title: item.book.title,
        price: item.book.price,
        qty: item.qty,
        image: item.book.image
      };
    });

    const razorpayOrder = await razorpay.orders.create({
      amount: totalAmount * 100,
      currency: "INR",
      receipt: "receipt_" + Date.now()
    });

    // ✅ SAVE ORDER ONCE (PENDING)
    const order = await Order.create({
      userId: user.id,
      items,
      totalAmount,
      paymentMethod: "ONLINE",
      paymentStatus: "PENDING",
      status: "Pending"
    });

    // order id session me save
    req.session.lastOrderId = order._id;

    res.json({
      razorpayOrderId: razorpayOrder.id,
      amount: razorpayOrder.amount
    });

  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Order failed" });
  }
});

app.post("/payment-success", async (req, res) => {
  const orderId = req.session.lastOrderId;

  await Order.findByIdAndUpdate(orderId, {
    paymentStatus: "PAID",
    status: "Order Placed"
  });

  req.session.cart = [];
  req.session.buyNow = null;

  // ✅ YAHI SABSE IMPORTANT LINE HAI
  res.redirect(`/order-success/${orderId}`);
});

app.get("/order-success/:id", (req, res) => {
  res.render("orderSuccess", {
    orderId: req.params.id
  });
});

// 📦 ORDER DETAILS PAGE
app.get("/order/:id", async (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }

  const order = await Order.findById(req.params.id);

  res.render("orderTrack", {
    order,
    user: req.session.user
  });
});

// 🟢 USER MY ORDERS PAGE
app.get("/my-orders", async (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }

  try {
    const orders = await Order.find({
      userId: req.session.user.id
    }).sort({ createdAt: -1 });

    res.render("my-orders", {
      user: req.session.user,
      orders
    });
  } catch (err) {
    console.log(err);
    res.send("Error loading orders");
  }
});

app.get("/wishlist", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const wishlist = await Wishlist.find({
    userId: req.session.user.id
  }).populate("bookId");

  res.render("wishlist", {
    user: req.session.user,
    wishlist
  });
});

// ❤️ TOGGLE WISHLIST (ADD + REMOVE)
app.post("/wishlist/toggle/:bookId", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const userId = req.session.user.id;
  const bookId = req.params.bookId;

  const exists = await Wishlist.findOne({ userId, bookId });

  if (exists) {
    await Wishlist.deleteOne({ userId, bookId });
  } else {
    await Wishlist.create({ userId, bookId });
  }

  // 🔥 SAFE REDIRECT
  res.redirect(req.headers.referer || "/");
});

app.get("/wishlist/remove/:bookId", async (req, res) => {
  await Wishlist.deleteOne({
    userId: req.session.user.id,
    bookId: req.params.bookId
  });

  res.redirect("/wishlist");
});

// 👤 USER PROFILE PAGE
app.get("/profile", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const user = req.session.user;

  const orders = await Order.find({ userId: user.id })
    .sort({ createdAt: -1 })
    .limit(5);

  const wishlistCount = await Wishlist.countDocuments({
    userId: user.id
  });

  res.render("profile", {
    user,
    orders,
    wishlistCount
  });
});

app.get("/profile/edit", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const user = await User.findById(req.session.user.id);

  res.render("editProfile", { user });
});

// ✏️ UPDATE PROFILE
app.post("/profile/edit", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const { name, email } = req.body;

  await User.findByIdAndUpdate(req.session.user.id, {
    name,
    email
  });

  // session update (VERY IMPORTANT)
  req.session.user.name = name;
  req.session.user.email = email;

  res.redirect("/profile");
});

// 🔐 CHANGE PASSWORD
app.post("/profile/change-password", async (req, res) => {
  if (!req.session.user) return res.redirect("/login");

  const { oldPassword, newPassword } = req.body;

  const user = await User.findById(req.session.user.id);
  if (!user) return res.redirect("/login");

  const match = await bcrypt.compare(oldPassword, user.password);
  if (!match) {
    return res.render("profile", {
      user: req.session.user,
      error: "Old password is incorrect"
    });
  }

  const hashedPassword = await bcrypt.hash(newPassword, 10);
  user.password = hashedPassword;
  await user.save();

  res.redirect("/profile");
});

app.post("/profile/address/add", async (req, res) => {
  const user = await User.findById(req.session.user.id);

const { fullName, phone, address, city, state, pincode } = req.body;

const alreadyExists = user.addresses.some(a =>
  a.fullName === fullName &&
  a.phone === phone &&
  a.address === address &&
  a.city === city &&
  a.state === state &&
  a.pincode === pincode
);

if (!alreadyExists) {
  user.addresses.push({
    fullName,
    phone,
    address,
    city,
    state,
    pincode
  });
  await user.save();
}
  req.session.user = user; // 🔥 MUST
  res.redirect("/profile/edit");
});

app.get("/profile/address/delete/:id", async (req, res) => {
  await User.findByIdAndUpdate(req.session.user.id, {
    $pull: { addresses: { _id: req.params.id } }
  });

  res.redirect("/profile/edit");
});

const storage = multer.diskStorage({
  destination: "public/uploads",
  filename: (req, file, cb) => {
    cb(null, Date.now() + file.originalname);
  }
});

const upload = multer({ storage });

app.post("/profile/image", upload.single("image"), async (req, res) => {
  await User.findByIdAndUpdate(req.session.user.id, {
    profileImage: "/uploads/" + req.file.filename
  });

  req.session.user.profileImage = "/uploads/" + req.file.filename;
  res.redirect("/profile");
});

app.listen(PORT, () => console.log(`User server running on http://localhost:${PORT}`));
