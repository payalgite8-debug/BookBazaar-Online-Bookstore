import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "payalgite8@gmail.com",
    pass: "ffcbuhlewpjokrwm"
  }
});

export const sendOtpEmail = async (email, otp) => {
  await transporter.sendMail({
    from: "BookBazaar <YOUR_EMAIL@gmail.com>",
    to: email,
    subject: "Your BookBazaar OTP",
    html: `<h2>Your OTP is: ${otp}</h2><p>Valid for 2 minutes</p>`
  });
};
